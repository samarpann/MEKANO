<?php
session_start();

if ($_SESSION["valid"] == "true") {
	$valid_count = $_SESSION["validcount"];    
	$_SESSION["validcount"] = $valid_count + 1;  
	} else {
	$_SESSION["valid"] = "true";
	$_SESSION["validcount"] = "1";
	$_SESSION["timeout"] = time() + 36000;
}

function get_input($key) {
    return isset($_POST[$key]) ? trim($_POST[$key]) : (isset($_SESSION[$key]) ? trim($_SESSION[$key]) : "");
}




$api_key = "eb9843ac86";
$publisher_id = "3533";
$offer_id = "2564";

$publisher_sub_id    = get_input("pub_sub_id");
$publisher_order_id  = get_input("publisher_order_id");
$click_id            = get_input("click_id");
$extra_id_1          = get_input("extra_id_1");
$extra_id_2          = get_input("extra_id_2");
$stream_id           = get_input("stream_id");


$api_url = "https://api.ezaff.com/send";

function onlyaz($value) {
	if (empty($value)) return "";
	// Allow + character for phone numbers
	$result = preg_replace("/[^\s\w_:,-.+]+/u", "", $value);
	return $result;
}

function getIPAddress() 
	{
		foreach (array("HTTP_CLIENT_IP", "HTTP_X_FORWARDED_FOR", "HTTP_X_FORWARDED", "HTTP_X_CLUSTER_CLIENT_IP", "HTTP_FORWARDED_FOR", "HTTP_FORWARDED", "REMOTE_ADDR","HTTP_CF_CONNECTING_IP") as $key) {
			if (array_key_exists($key, $_SERVER) === true) {
				foreach (explode(",", $_SERVER[$key]) as $ip) {
					if (filter_var($ip, FILTER_VALIDATE_IP) !== false) {
						return $ip;
					}
				}
			}
		}
		return "";
	}

function sanitizePhone($phone) {
	if (empty($phone)) return "";
	
	$phone = trim($phone);
	$phone = preg_replace('/\s+/', '', $phone);
	$phone = preg_replace('/[^0-9+]/', '', $phone);
	
	if (strpos($phone, '+48') === 0) {
		$phone = substr($phone, 3);
	}
	
	$phone = ltrim($phone, '0');
	$phone = preg_replace('/[^0-9]/', '', $phone);
	
	if (strlen($phone) === 9) {
		return '+48' . $phone;
	}
	
	return "";
}

$name = isset($_POST["name"]) ? onlyaz($_POST["name"]) : "";
$phone_raw = isset($_POST["phone"]) ? $_POST["phone"] : "";
$phone = sanitizePhone($phone_raw);

if (empty($name) || empty($phone)) {
	echo "<body onload='history.go(-1);'>";
	exit;
}
	
$post = array(
		"offer_id" => $offer_id,
		"publisher_id" => $publisher_id,
		"api_key" => $api_key,
		"name" => $name,
		"phone" => $phone,	
		"email" => "",
		"click_id" => $click_id,
		"publisher_sub_id" => $publisher_sub_id ,
		"publisher_order_id" => $publisher_order_id,
		"extra_id_1" => $extra_id_1,
		"extra_id_2" => $extra_id_2,
		"stream_id" => $stream_id,
		"extra_note" => "",
		"city" => "",
		"post_code" => "",
		"country" => "PL",
		"address" => "",
		"state" => "",
		"district" => "",
		"quantity" => "1",
		"price" => "99",
		"price_currency" => "PLN",
		"client_ip" => getIPAddress(),
		"order_note" => "",
		"bundle_option" => "",
		"payment_method" => "",
		"browser_agent" => isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : "",
		"ref_url" => isset($_SERVER["HTTP_HOST"]) ? $_SERVER["HTTP_HOST"] : "",
		"product_id" => ""
);

if ( !empty($name) && !empty($phone) && ($_SESSION["validcount"] < "100")  ) {
	$ch = curl_init($api_url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
	curl_setopt($ch, CURLOPT_TIMEOUT, 30);
	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
	$response = curl_exec($ch);
	$curl_error = curl_error($ch);
	curl_close($ch);
	
	if ($curl_error) {
		error_log("CURL Error: " . $curl_error);
		echo "<body onload='history.go(-1);'>";
		exit;
	}
	
	$obj = json_decode($response, true);
	
	if ($obj && isset($obj["status"]) && $obj["status"] == "success") {
		header("location: success.php");
		exit;
	} else {
		// Log EZAFF failure to console
		echo "<script>console.error('EZAFF API Error: " . addslashes($response) . "');</script>";
		error_log("API Response: " . $response);
		// Wait 1 second before going back
		echo "<script>setTimeout(function(){ history.go(-1); }, 1000);</script>";
		exit;
	}	
} else {
	echo "<body onload='history.go(-1);'>";
	exit;
}	
?>