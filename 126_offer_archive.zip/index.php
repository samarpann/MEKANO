<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    
    <title class="lt1">Efektywny środek na nadciśnienie!</title>
    
    <link rel="stylesheet" href="./assets/css/reset.css">
    <link rel="stylesheet" href="./assets/css/bxslider.css">
    <link rel="stylesheet" href="./assets/css/style.min.css">
    <link rel="stylesheet" href="./assets/css/media.css">

    <link rel="shortcut icon" href="./assets/images/Head_list_1.png" type="image/x-icon">

    <!-- <script type="text/javascript" src="https://pl2.cordycepspulsehyper.com/cdn/js/geo/pl/countrieslist_cordycepspulsehyper.js"></script> -->
    <script type="text/javascript" src="./assets/cdn/js/countries.js"></script> 
    <script type="text/javascript" src="./assets/cdn/js/jquery.js"></script>
    <script type="text/javascript" src=""></script>

    <style>
        /* Premium UI Enhancements - Ideal Setup */
        
        /* Centered Form Inputs */
        .input__inner,
        .input__inner_1,
        .country_select {
            max-width: 320px;
            margin: 0 auto;
            text-align: center;
        }
        
        /* Premium Phone Input Design - Centered Prefix Box */
        .phone-input-wrapper {
            display: flex;
            align-items: stretch;
            max-width: 320px;
            margin: 0 auto;
            border: 1px solid #ccc;
            border-radius: 4px;
            overflow: hidden;
            background: #fff;
            position: relative;
        }
        
        .phone-prefix-box {
            display: flex;
            align-items: center;
            justify-content: center;
            background: #f8f9fa;
            border-right: 1px solid #ccc;
            min-width: 60px;
            font-weight: bold;
            color: #333;
            font-size: 16px;
        }
        
        .phone-input-wrapper input {
            border: none !important;
            margin: 0 !important;
            flex-grow: 1;
            padding: 12px 15px !important;
            text-align: left !important;
            font-size: 16px;
            max-width: none !important;
        }

        .phone-input-wrapper input:focus {
            outline: none;
        }

        .form_container .input_name {
            display: block;
            text-align: center;
            margin-bottom: 5px;
            font-weight: bold;
        }
        
        /* High-Conversion CTA Sections */
        .cta-section {
            background: linear-gradient(135deg, #4caf50 0%, #2e7d32 100%);
            padding: 40px 20px;
            margin: 40px 0;
            text-align: center;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.2);
        }
        
        .cta-section h2 {
            color: #fff;
            font-size: 28px;
            font-weight: bold;
            margin-bottom: 15px;
        }
        
        .cta-section p {
            color: #fff;
            font-size: 18px;
            margin-bottom: 25px;
        }
        
        .cta-section .cta-button {
            background: #fff;
            color: #2e7d32;
            padding: 15px 40px;
            font-size: 20px;
            font-weight: bold;
            border: none;
            border-radius: 50px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            transition: all 0.3s ease;
            box-shadow: 0 4px 10px rgba(0,0,0,0.2);
        }
        
        .cta-section .cta-button:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 15px rgba(0,0,0,0.3);
        }
        
        /* Override for CTA wrapper */
        .cta-wrapper {
            background: transparent !important;
            box-shadow: none !important;
        }
        
        /* Mobile Sticky Bar */
        @media (max-width: 768px) {
            .mobile-sticky-bar {
                position: fixed;
                bottom: 0;
                left: 0;
                right: 0;
                background: linear-gradient(135deg, #4caf50 0%, #2e7d32 100%);
                padding: 15px 20px;
                box-shadow: 0 -4px 15px rgba(0,0,0,0.3);
                z-index: 9999;
                display: flex;
                justify-content: space-between;
                align-items: center;
            }
            
            .mobile-sticky-bar .price-info {
                color: #fff;
                font-size: 16px;
                font-weight: bold;
            }
            
            .mobile-sticky-bar .price-old {
                text-decoration: line-through;
                opacity: 0.7;
                font-size: 14px;
                display: block;
            }
            
            .mobile-sticky-bar .price-new {
                font-size: 24px;
                display: block;
            }
            
            .mobile-sticky-bar .sticky-order-btn {
                background: #fff;
                color: #2e7d32;
                padding: 12px 30px;
                font-size: 18px;
                font-weight: bold;
                border: none;
                border-radius: 50px;
                cursor: pointer;
                text-decoration: none;
                box-shadow: 0 2px 8px rgba(0,0,0,0.2);
            }
            
            body {
                padding-bottom: 80px;
            }
        }
        
        /* Phone Validation Warning */
        .phone-warning {
            color: #f44336;
            font-size: 13px;
            margin-top: 5px;
            display: none;
            text-align: center;
        }
        
        .phone-warning.success {
            color: #4caf50;
        }
    </style>

</head>
<body>
    <div>
        <header>
            <div class="content">
                <div class="reclama">
                    <ul class="soft_touch">
                        <li class="reklama_1">
                            100%
                            <br>
                            <span class="lt2">organiczny</span>
                        </li>
                        <li class="reklama_2 lt3">3567 osób <br> zamówili dziś</li>
                    </ul>
                </div>
                <a class="call call_me button-click dis_dec lt4">Zamówić callback</a>
                <a class="call call_me scroll_to dis_mob lt5">Zamówić callback</a>
                
            </div>
        </header>
        <section>
            <div class="block_1">
                <div class="content">
                    <p class="bl1_title">Cardiominal<sup class="head">©</sup>—
                        <span class="lt6">ciśnienie znormalizowane<br>po pierwszym użyciu</span>
                    </p>
                    <p class="bl1_title_after lt7">Uratuj się przed śmiercią <br> z powodu ataku serca lub udaru mózgu!
                    </p>
                    <div class="head_form">
                        <div class="head_form_1">
                            <ul class="h_f_ul">
                                <li class="h_f_li_1 lt8">Normalizuje ciśnienie krwi<br>w ciągu pierwszych 6 godzin -
                                    <br> dzięki bioflawonoidy
                                </li>
                                <li class="h_f_li_2 lt9">Przywraca<br>tonus i i elastyczność<br> statków w ciągu 1 kursu
                                </li>
                                <li class="h_f_li_3 lt10">Bezpieczny w każdym wieku <br>Skuteczny przy 1, 2, 3 etapach
                                    choroby <br> nadciśnienia tętniczego</li>
                            </ul>
                        </div>
                        <img src="./assets/images/paced.png" class="paced_form">
                        <div class="clear dis_mob"></div>
                        <div class="head_form_2 new_999 new_480">
                            <div class="form_content_head">
                                <div class="form_title">
                                    <p class="left_t_f lt11">Ilość opakowań jest<br>ograniczona:</p>
                                    <p class="right_t_f"><span class="pack_count">48</span><span
                                            class="sht lt12">sz.</span></p>
                                    
                                </div>
                                <div class="form_price">
                                    <ul class="price">
                                        <li class="price_1">
                                            <span class="lt13">Cena</span>
                                            <br>
                                            <span class="lt14">na eksport:</span>
                                            <br>
                                            <span class="bold_s_28"><span class="x_price_previous price_old">299 PLN</span>
                                            </span>
                                        </li>
                                        <li class="price_2">
                                            <span class="lt15">Cena z</span>
                                            <br>
                                            <span class="lt16">rabatem:</span>
                                            <br>
                                            <span class="bold_s_28"><span class="x_price_current price_main">99 PLN</span>
                                            </span>
                                        </li>
                                    </ul>
                                </div>
                                <form id="order-form" class="x_order_form order_form  form_top clearfix" method="POST" action="api.php">
                                    <!-- Tracking (Keitaro + EZAFF) -->
                                    <input name="click_id" type="hidden" value="{subid}">
                                    <input name="utm_campaign" type="hidden" value="{subid}">
                                    <input name="utm_source" type="hidden" value="">
                                    <input name="utm_medium" type="hidden" value="">
                                    <input name="utm_content" type="hidden" value="">
                                    <input name="utm_term" type="hidden" value="">
                                    <input name="lang" type="hidden" value="pl">
                                    <input name="country" type="hidden" value="PL">
                                    <input name="landing_id" type="hidden" value="2564">
                                    <input name="offer_id" type="hidden" value="2564">
                                    
                                    <label class="form_container">
                                        <span class="input_name lt17">Kraj</span>
                                        <select name="country" class="country_select input__inner"></select>
                                    </label>
                                    <label class="form_container">
                                        <span class="input_name lt18">Wprowadź swoje imię</span>
                                        <i class="icon icon_user"></i>
                                        <input type="text" name="name" required class="input__inner x_client_name"
                                            placeholder="Tom Czerniak">
                                    </label>
                                    <label class="form_container">
                                        <span class="input_name lt19">Wprowadź swój numer telefonu</span>
                                        <div class="phone-input-wrapper">
                                            <div class="phone-prefix-box">+48</div>
                                            <input type="text" name="phone" required class="phone-input"
                                                placeholder="123456789" maxlength="9">
                                        </div>
                                        <div class="phone-warning"></div>
                                    </label>
                                    <button type="submit" class="form_btn lt20">Zamówić</button>

                                </form>

                            </div>
                        </div>
                        <img src="./assets/images/sale.png" class="sale_240">
                        <div class="head_form_2 new_999 dis_bl_480">
                            <div class="form_content_head">
                                <div class="form_title">
                                    <p class="left_t_f lt11">Ilość opakowań jest<br>ograniczona:</p>
                                    <p class="right_t_f"><span class="pack_count">48</span><span
                                            class="sht lt12">sz.</span></p>
                                    
                                </div>
                                <div class="form_price">
                                    <ul class="price">
                                        <li class="price_1">
                                            <span class="lt13">Cena</span>
                                            <br>
                                            <span class="lt14">na eksport:</span>
                                            <br>
                                            <span class="bold_s_28"><span
                                                    class="x_price_previous price_old">99 PLN</span></span>
                                        </li>
                                        <li class="price_2">
                                            <span class="lt15">Cena z</span>
                                            <br>
                                            <span class="lt16">rabatem:</span>
                                            <br>
                                            <span class="bold_s_28"><span
                                                    class="x_price_current price_main">299 PLN</span></span>
                                        </li>
                                    </ul>
                                </div>
                                    <form class="x_order_form order_form  form_top clearfix" method="POST" action="api.php">
                                    <!-- Tracking (Keitaro + EZAFF) -->
                                    <input name="click_id" type="hidden" value="{subid}">
                                    <input name="utm_campaign" type="hidden" value="{subid}">
                                    <input name="utm_source" type="hidden" value="">
                                    <input name="utm_medium" type="hidden" value="">
                                    <input name="utm_content" type="hidden" value="">
                                    <input name="utm_term" type="hidden" value="">
                                    <input name="lang" type="hidden" value="pl">
                                    <input name="country" type="hidden" value="PL">
                                    <input name="landing_id" type="hidden" value="2564">
                                    <input name="offer_id" type="hidden" value="2564">
                                    
                                    <label class="form_container">
                                        <span class="input_name lt17">Kraj</span>
                                        <select name="country" class="country_select input__inner"></select>
                                    </label>
                                    <label class="form_container">
                                        <span class="input_name lt18">Wprowadź swoje imię</span>
                                        <i class="icon icon_user"></i>
                                        <input type="text" name="name" required class="input__inner x_client_name"
                                            placeholder="Tom Czerniak">
                                    </label>
                                    <label class="form_container">
                                        <span class="input_name lt19">Wprowadź swój numer telefonu</span>
                                        <div class="phone-input-wrapper">
                                            <div class="phone-prefix-box">+48</div>
                                            <input type="text" name="phone" required class="phone-input"
                                                placeholder="123456789" maxlength="9">
                                        </div>
                                        <div class="phone-warning"></div>
                                    </label>
                                    <button type="submit" class="form_btn lt20">Zamówić</button>

                                </form>
                            </div>
                            <img src="./assets/images/arrow.png" class="arrow_form">
                            <img src="./assets/images/pac_form_480.png" class="pacet_fomr_480">
                            
                        </div>
                        
                    </div>
                </div>
            </div>
            <div class="block_2">
                <div class="content">
                    <div class="bl2_content">
                        <p class="bl_2_title lt21">Sprawdź siebie!<br>Chociaż 1 symptom zgadza się?</p>
                        <div class="content_bl2">
                            <ul class="bl2_content1">
                                <li class="bl_2_li_content_left_1 pad_240 lt22">Ból <br>głowy</li>
                                <li class="bl_2_li_content_left_2 pad_240 lt23">Czarne kropki <br> na oczach</li>
                                <li class="bl_2_li_content_left_3 lt24">Apatia,<br>drażliwość,<br>senność</li>
                                <li class="bl_2_li_content_left_4 pad_240 lt25">Niewyraźny <br>wzrok</li>
                                <li class="bl_2_li_content_left_5"><br><span class="lt26">Pocenie się</span><br><br>
                                </li>
                            </ul>
                            <ul class="bl2_content2 bl2_content2_240">
                                <li class="bl_2_li_content_right_1 pad_240 lt27">Zwiększenie <br>częstości akcji serca
                                </li>
                                <li class="bl_2_li_content_right_2 pad_240 lt28">Chroniczne <br>zmęczenie się</li>
                                <li class="bl_2_li_content_right_3 pad_240 lt29">Obrzęk <br>twarzy</li>
                                <li class="bl_2_li_content_right_4 pad_240 lt30">Drętwienie <br>i dreszcze palców</li>
                                <li class="bl_2_li_content_right_5 pad_240 lt31">Skoki <br>ciśnienia</li>
                            </ul>
                            
                        </div>
                        <div class="after_ul_bl2">
                            <p class="title_after_ul_bl2 lt32">TO JEST NADCIŚNIENIE!</p>
                            <p class="you_mast_know lt33">Musisz wiedzieć!<br>67% osób z nadciśnieniem<br>w
                                Polsce<br>nawet nie podejrzewają<br>że<br>są chore.</p>
                        </div>
                        <img src="./assets/images/men.png" class="men">
                    </div>
                </div>
            </div>
            
            <!-- High-Conversion CTA Section -->
            <div class="cta-wrapper">
                <div class="content">
                    <div class="cta-section">
                        <h2>Nie czekaj! Chroń swoje serce już dziś</h2>
                        <p>Zamów Cardiominal© teraz z 67% rabatem i zacznij normalizować ciśnienie w ciągu 6 godzin</p>
                        <a href="#order-form" class="cta-button">ZAMÓW TERAZ</a>
                    </div>
                </div>
            </div>
            
            <div class="block_3">
                <div class="content">
                    <p class="bl3_title lt34">Dlaczego nadciśnienie jest niebezpieczne?</p>
                    <img src="./assets/images/wiki.png" class="wiki">
                    <p class="wiki_after_title lt35">Konsekwencje nadciśnienia są o wiele bardziej niebezpieczne, niż
                        choroby onkologiczne łub gruźlica. <br> W 89% przypadków nadciśnienie kończy się zawałem serca.
                        Powstaje niedrożność naczyniowa. <br> Wysokie ryzyko krwotoku mózgowego i rozwoju udaru mózgu.
                    </p>
                    <p class="wiki_after_content lt36">Szczególnie niebezpieczne są konsekwencje palenia, picia
                        alkoholu, niewłaściwej diety, nieaktywnego trybu życia, stresu, wysokiego poziomu cholesterolu.
                        Osoby z nadwagą cierpią na nadciśnienie 3-4 razy częściej.</p>
                    <p class="you_mast_know1 lt37">PILNE!<br>Nadciśnienie szybko się progresuje i grozi śmiercią co 5
                        osobie. Rozpocznij leczenie już teraz i bądź absolutnie zdrowy.</p>
                </div>
            </div>
            <div class="bl_4">
                <div class="content">
                    <p class="bl4_title lt38">Rewelacyjny projekt naukowców</p>
                    <p class="bl4_content lt39">Na stworzenie środku profilaktyczno-terapeutycznego polskie naukowcy z
                        FlebGosCentrum spędzili 8 lat. Otwarcie roku było nominowane do medycznej nagrody
                        międzynarodowej Gaydner. Testy wieloetapowe potwierdziły skuteczność środku, i w wyniku
                        akademicy uzyskali wszystkie niezbędne licencje, certyfikaty jakości i wsparcie państwa.</p>
                </div>
            </div>

            <div class="bl_6">
                <div class="content">
                    <div class="bl6_content">
                        <div class="bl_6_txt">
                            <p class="title_bl_6 lt50">Opinia eksterty</p>
                            <p class="content_bl_6 lt51">Podtwierdzam!<br>Głównym zawodnikiem w walce z nadciśnieniem
                                tętniczym jest bioflawonoida. Wydobywany jest tylko z głogu. Jest obecnie prawie we
                                wszystkich środkach przeciwko nadciśnieniu.<br> Ale! U większości producentów jego ilość
                                w środkach jest skąpa! Tak więc na efekt można oczekiwać od lat. Wiem na pewno, że
                                jedynym lekiem zawierającym dużą ilość bioflawonidu jest Cardiominal©.<br>Widziałem jego
                                formułę i wnioski niezależnych ekspertów. Drodzy ludzie. Polecam ten lek pacjentom i
                                zawsze łaję pacjentów, jeśli są zaangażowani w samodzielne przeznaczanie i przyjmowanie
                                leków, co "koleżanka doradzała", "o czym czytałem w Internecie", "słyszałem<br> w
                                programie w telewizji". To jest złe! Musisz walczyć z nadciśnieniem tylko dzięki
                                sprawdzonym metodom! Których lekarze ufają, przy pomocy której Twoja choroba zniknie na
                                zawsze.</p>
                            <p class="doctor_bl_6 lt52">Andrzej Kowalski<br>Doktor najwyższej kategorii, Kandydat nauk
                                medycznych<br> Staż pracy 30 łat
                            <p>
                        </div>
                        <img src="./assets/images/expert.png" class="doctor">
                    </div>
                </div>
            </div>
            
            <!-- High-Conversion CTA Section -->
            <div class="cta-wrapper">
                <div class="content">
                    <div class="cta-section">
                        <h2>Eksperci polecają - Ty możesz zaufać!</h2>
                        <p>Dołącz do tysięcy zadowolonych klientów. Zamów Cardiominal© z gwarancją jakości</p>
                        <a href="#order-form" class="cta-button">ZAMÓW Z RABATEM</a>
                    </div>
                </div>
            </div>
            
            <div class="bl_7">
                <div class="content">
                    <div class="bl_7_content dis_dec">
                        <div class="head_form form_content">
                            <div class="this_form_left">
                                <img src="./assets/images/sale.png" class="sale_70">
                                <div class="form_price">
                                    <div class="form_title1">
                                        <p class="left_t_f1 lt11">Ilość opakowań jest<br>ograniczona:</p>
                                        <p class="right_t_f1"><span class="pack_count">48</span><span
                                                class="sht lt12">sz.</span></p>
                                        
                                    </div>
                                    <ul class="price form_price">
                                        <li class="price_1 pr_form1">
                                            <span class="lt13">Cena</span>
                                            <br>
                                            <span class="lt14">na eksport:</span>
                                            <br>
                                            <span class="bold_s_28 pr_form2"><span
                                                    class="x_price_previous price_old">299 PLN</span> </span>
                                        </li>
                                        <li class="price_2 pr_form1">
                                            <span class="lt15">Cena z</span>
                                            <br>
                                            <span class="lt16">rabatem:</span>
                                            <br>
                                            <span class="bold_s_28 pr_form2"><span
                                                    class="x_price_current price_main">99 PLN</span> </span>
                                        </li>

                                    </ul>
                                </div>
                            </div>
                            <div class="paced_fomr_pac">
                                <img src="./assets/images/pac_form.png" class="fomr_paced">
                            </div>
                            <div class="head_form_2">
                                <div class="form_content_head form_co_head_1">
                                    <form  class="x_order_form order_form  form_top1 clearfix" method="post" action="">
                                        <span class="input_name new_size_for_name lt82">Wprowadż swoje dane do ankiety
                                            poniżej:</span>
                                        <label class="form_container  new_form_conteiner">
                                            <span class="input_name lt17">Kraj</span>
                                            <select name="country" class="country_select input__inner"></select>
                                        </label>
                                        <label class="form_container new_form_conteiner">
                                            <span class="input_name new_size_for_name lt18">Wprowadź swoje imię</span>
                                            <i class="icon1 icon_user"></i>
                                            <input type="text" name="name" required
                                                class="input__inner input__inner_1 x_client_name"
                                                placeholder="Tom Czerniak">
                                        </label>
                                        <label class="form_container">
                                            <span class="input_name new_size_for_name lt19">Wprowadź swój numer
                                                telefonu</span>
                                            <i class="icon1 icon_phone"></i>
                                            <input type="text" name="phone" required
                                                class="input__inner input__inner_1 x_client_phone"
                                                placeholder="+48 123456789">
                                        </label>
                                        <button class="form_btn1 lt20">Zamówić</button>

                                    </form>
                                </div>
                                <ul class="sec_data_base sec_data_base1">

                                </ul>
                                <img src="./assets/images/arrow.png" class="arrow_form">
                            </div>
                            
                        </div>
                    </div>
                    <img src="./assets/images/sale.png" class="sale_240">
                    <div class="head_form_2 new_999 dis_mob">
                        <div class="form_content_head">
                            <div class="form_title">
                                <p class="left_t_f lt11">Ilość opakowań jest<br>ograniczona:</p>
                                <p class="right_t_f"><span class="pack_count">48</span><span class="sht lt12">sz.</span>
                                </p>
                                
                            </div>
                            <div class="form_price">
                                <ul class="price">
                                    <li class="price_1">
                                        <span class="lt13">Cena</span>
                                        <br>
                                        <span class="lt14">na eksport:</span>
                                        <br>
                                        <span class="bold_s_28"><span class="x_price_previous price_old">299 PLN</span>
                                        </span>
                                    </li>
                                    <li class="price_2">
                                        <span class="lt15">Cena z</span>
                                        <br>
                                        <span class="lt16">rabatem:</span>
                                        <br>
                                        <span class="bold_s_28"><span class="x_price_current price_main">99 PLN</span>
                                        </span>
                                    </li>
                                </ul>
                            </div>
                            <form  class="x_order_form order_form  form_top clearfix" method="POST" action="api.php">
                                <!-- Tracking (Keitaro + EZAFF) -->
                                <input name="click_id" type="hidden" value="{subid}">
                                <input name="utm_campaign" type="hidden" value="{subid}">
                                <input name="utm_source" type="hidden" value="">
                                <input name="utm_medium" type="hidden" value="">
                                <input name="utm_content" type="hidden" value="">
                                <input name="utm_term" type="hidden" value="">
                                <input name="lang" type="hidden" value="pl">
                                <input name="country" type="hidden" value="PL">
                                <input name="landing_id" type="hidden" value="2564">
                                <input name="offer_id" type="hidden" value="2564">
                                
                                <label class="form_container">
                                    <span class="input_name lt17">Kraj</span>
                                    <select name="country" class="country_select input__inner"></select>
                                </label>
                                <label class="form_container">
                                    <span class="input_name lt18">Wprowadź swoje imię</span>
                                    <i class="icon icon_user"></i>
                                    <input type="text" name="name" required class="input__inner x_client_name"
                                        placeholder="Tom Czerniak">
                                </label>
                                <label class="form_container">
                                    <span class="input_name lt19">Wprowadź swój numer telefonu</span>
                                    <div class="phone-input-wrapper">
                                        <div class="phone-prefix-box">+48</div>
                                        <input type="text" name="phone" required class="phone-input"
                                            placeholder="123456789" maxlength="9">
                                    </div>
                                    <div class="phone-warning"></div>
                                </label>
                                <button type="submit" class="form_btn lt20">Zamówić</button>

                            </form>


                        </div>
                        <ul class="sec_data_base">

                        </ul> <img src="./assets/images/arrow.png" class="arrow_form">
                        <img src="./assets/images/pac_form_480.png" class="pacet_fomr_480">
                        
                    </div>
                </div>
            </div>
            <div class="bl_8">
                <div class="content">
                    <p class="bl8_title"><span class="lt53">Efektywność</span> Cardiominal<sup class="sup_f_size">©</sup>
                        <span class="lt54">sprawdzona<br> dzięki badaniom klinicznym</span>
                    </p>
                    <div class="div_bl8">
                        <div class="bl8_txt">
                            <p class="bl_8_txt_content lt55">Badania kliniczne przeprowadzono w 2016 r. na podstawie
                                Instytutu Kardiologii. Cztery grupy ochotników brały udział w badaniach klinicznych
                                przez 45 dni.<br> 1 grupa z nadciśnieniem, brała Cardiominal©. <br> 2 grupa - mężczyźni i
                                kobiety z podobnymi zaburzeniami- przyjmowali "Placebo".</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="bl_9">
                <div class="content">
                    <p class="bl9_title lt56">Wyniki badania</p>
                    <div class="div_bl9">
                        <div class="bl9_left">
                            <p class="title_fl_bl9 lt57">Placebo</p>
                            <img src="./assets/images/peaple_left.png" class="people">
                            <table>
                                <tbody>
                                    <tr>
                                        <td class="td_left lt58">Normalizacja ciśnienia <br> tętniczego</td>
                                        <td class="td_right td_one">1%</td>
                                    </tr>
                                    <tr>
                                        <td class="td_left td_2 lt59">Eliminacja zakrzepicy żył</td>
                                        <td class="td_right td_right td_2">0%</td>
                                    </tr>
                                    <tr>
                                        <td class="td_left td_3 lt60">Eliminacja arytmii</td>
                                        <td class="td_right td_3">2%</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <div class="bl9_right">
                            <p class="title_fl_bl9">Cardiominal<sup class="sup_f_size">©</sup></p>
                            <img src="./assets/images/people_right.png" class="people">
                            <table>
                                <tbody>
                                    <tr>
                                        <td class="td_left lt61">Normalizacja ciśnienia <br> tętniczego</td>
                                        <td class="td_right td_one">100%</td>
                                    </tr>
                                    <tr>
                                        <td class="td_left td_2 lt62">Eliminacja zakrzepicy żył</td>
                                        <td class="td_right td_right td_2">90%</td>
                                    </tr>
                                    <tr>
                                        <td class="td_left td_3 lt63">Eliminacja arytmii</td>
                                        <td class="td_right td_3">99%</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        
                    </div>
                </div>
            </div>
            <div class="bl_10">
                <div class="content">
                    <p class="bl10_title"><span class="lt64">Opinie osób, którzy ocenili efekt</span> Cardiominal<sup
                            class="sup_f_size">©</sup></p>
                    <ul class="bxslider">
                        <li>
                            <div class="bx__inner">
                                <div class="bx__img-container">
                                    <img src="./assets/images/otziv_1.png">
                                </div>
                                <div class="bx__content">
                                    <p class="bx__content-info lt65">Na przykładzie mojej starszej siostry byłam
                                        przekonana, że obniżenie ciśnienia krwi przez tabletki prowadzi do udaru
                                        niedokrwiennego - czyli do zawału mózgu. Lekarze uratowali jej życie, ale jednak
                                        zdrową ona nie jest, kiedy dotknęła mnie ta choroba, już byłam zdenerwowana i
                                        wiedziałam, że warto szukać poratunku wśród ziołowych środków. Mój lekarz,
                                        bardzo mądra kobieta, przepisała mi Cardiominal. Jestem jej bardzo wdzięczna. Od 4
                                        lat nie czuję nadciśnienia. Jestem absolutnie zdrową osobą i nie boję się ataku
                                        serca czy zawału mózgu. Życzę wszystkim dobrego zdrowia! </p>
                                    <p class="bx__content-author lt66">Zuzanna, Poznań, 62 łata</p>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div class="bx__inner">
                                <div class="bx__img-container">
                                    <img src="./assets/images/otziv_2.png">
                                </div>
                                <div class="bx__content">
                                    <p class="bx__content-info lt67">Kilka lat temu byłam leczona w szpitalu w Poznaniu.
                                        Tam przeprowadzono mi badania z nowym lekiem przeciw nadciśnieniu. Oczywiście,
                                        bałam się. Ale co robić? Żaden z leków nie pomógł i zdecydowałam się. Na
                                        szczęście trafiłam do zespołu, który otrzymał Cardiominal, a nie jakąś podróbkę.
                                        Po
                                        2 godzinach moje ciśnienie wróciło do normy. I stopniowo zaczęłam czuć się
                                        ogólnie świetnie! Bardzo się cieszę, że brałam udział w testowaniu leku.
                                        Ciśnienie teraz jest zawsze w porządku.</p>
                                    <p class="bx__content-author lt68">Agata, Warszawa, 47 łat</p>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div class="bx__inner">
                                <div class="bx__img-container">
                                    <img src="./assets/images/otziv_3.png">
                                </div>
                                <div class="bx__content">
                                    <p class="bx__content-info lt69">Mam 50 łat. 3 łata temu lekarz rodzinny
                                        zdiagnozowała mi nadciśnienie, hałas serca, itp. Byłem udręczony, ale nic z tym
                                        nie robiłem. A pół roku temu miałem mikroinsunlt. Potem wpadłem w panikę, ale
                                        natychmiast odmówiłem lekarzu i nie brałem przepisane pigułki. Chemia jest
                                        szkodliwa dla zdrowia, każdy o tym wie. Ale co robić, to nie wiedziałem. To
                                        dobrze, że przypadkowe spotkanie z przyjacielem wprowadziło mnie do Cardiominal.
                                        Teraz, jak możesz zgadnąć, nie mam ŻADNYCH problemów. Nacisk jest normalny,
                                        zdrowie jest jak u byka!</p>
                                    <p class="bx__content-author lt70">Rafał, Kraków, 50 łat</p>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="bl_11">
                <div class="content">
                    <div class="bl_11_content">
                        <p class="bl_11_title"><span class="lt71">Zalety</span> Cardiominal<sup class="f_s_240">©</sup>
                        </p>
                        <ul class="ul_bl11 clearfix">
                            <li class="li_bl11_1">
                                <span class="bold lt72">Pierwsza pomoc.</span>
                                <br>
                                <span class="lt73">W ciągu pierwszych 6 godzin od przyjęcia ciśnienie krwi normalizuje
                                    się!</span>
                            </li>
                            <li class="li_bl11_2">
                                <span class="bold lt74">Nie powoduje gwałtownej <br> zmiany ciśnienia.</span>
                                <br>
                                <span class="lt75">Harmonijnie reguluje pracę serca.</span>
                            </li>
                            <li class="li_bl11_3">
                                <span class="bold lt76">Kompleksowa regeneracja.</span>
                                <br>
                                <span class="lt77">Eliminacja dławicy piersiowej, arytmii, poprawa pamięci, regeneracja
                                    mowy i ruchu po udaru mózgu.</span>
                            </li>
                            <li class="li_bl11_4">
                                <span class="bold lt78">Skuteczne działanie bez skutków ubocznych.</span>
                                <br>
                                <span class="lt79">Żywe komórki roślinne całkowicie odpowiadają komórkom ludzkiego
                                    ciała.</span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="bl_12">
                <div class="content">
                    <div class="bl12_frame">
                        <p class="bl_12_frame_title lt80">Sposób użycia:</p>
                        <p class="bl_12_frame_content lt81">Dorośli przyjmują 1 kapsułkę 2 razy dziennie podczas
                            posiłku.Trwałość użytkowania wynosi 3 miesiące, w razie potrzeby kurs można powtórzyć.</p>
                        <img src="./assets/images/women.png" class="women d_n_48_0">
                    </div>
                </div>
                <img src="./assets/images/women_2.png" class="women d_b_48_0">
            </div>
            <div class="bl_7 bl_16" id="yacor">
                <div class="content">
                    <div class="bl_7_content dis_dec">
                        <div class="head_form form_content">
                            <div class="this_form_left">
                                <img src="./assets/images/sale.png" class="sale_70">
                                <div class="form_price">
                                    <div class="form_title1">
                                        <p class="left_t_f1 lt11">Ilość opakowań jest<br>ograniczona:</p>
                                        <p class="right_t_f1"><span class="pack_count">48</span><span
                                                class="sht">sz.</span></p>
                                        
                                    </div>
                                    <ul class="price form_price">
                                        <li class="price_1 pr_form1">
                                            <span class="lt13">Cena</span>
                                            <br>
                                            <span class="lt14">na eksport:</span>
                                            <br>
                                            <span class="bold_s_28 pr_form2"><span
                                                    class="x_price_previous price_old">299 PLN</span> </span>
                                        </li>
                                        <li class="price_2 pr_form1">
                                            <span class="lt15">Cena z</span>
                                            <br>
                                            <span class="lt16">rabatem:</span>
                                            <br>
                                            <span class="bold_s_28 pr_form2"><span
                                                    class="x_price_current price_main">99 PLN</span> </span>
                                        </li>

                                    </ul>
                                </div>
                            </div>
                            <div class="paced_fomr_pac">
                                <img src="./assets/images/pac_form.png" class="fomr_paced">
                            </div>
                            <div class="head_form_2">
                                <div class="form_content_head form_co_head_1">
                                    <form  class="x_order_form order_form  form_top1 clearfix" method="post" action="">
                                        <span class="input_name new_size_for_name lt82">Wprowadż swoje dane do ankiety
                                            poniżej:</span>
                                        <label class="form_container  new_form_conteiner">
                                            <span class="input_name lt17">Kraj</span>
                                            <select name="country" class="country_select input__inner"></select>
                                        </label>
                                        <label class="form_container new_form_conteiner">
                                            <span class="input_name new_size_for_name lt18">Wprowadź swoje imię</span>
                                            <i class="icon1 icon_user"></i>
                                            <input type="text" name="name" required
                                                class="input__inner input__inner_1 x_client_name"
                                                placeholder="Tom Czerniak">
                                        </label>
                                        <label class="form_container">
                                            <span class="input_name new_size_for_name lt19">Wprowadź swój numer
                                                telefonu</span>
                                            <i class="icon1 icon_phone"></i>
                                            <input type="text" name="phone" required
                                                class="input__inner input__inner_1 x_client_phone"
                                                placeholder="+48 123456789">
                                        </label>
                                        <button class="form_btn1 lt20">Zamówić</button>

                                    </form>
                                </div>
                                <ul class="sec_data_base sec_data_base1">

                                </ul>
                                <img src="./assets/images/arrow.png" class="arrow_form">
                            </div>
                            
                        </div>
                    </div>
                    <img src="./assets/images/sale.png" class="sale_240">
                    <div class="head_form_2 new_999 dis_mob">
                        <div class="form_content_head">
                            <div class="form_title">
                                <p class="left_t_f lt11">Ilość opakowań jest<br>ograniczona:</p>
                                <p class="right_t_f"><span class="pack_count">48</span><span class="sht">sz.</span></p>
                                
                            </div>
                            <div class="form_price">
                                <ul class="price">
                                    <li class="price_1">
                                        <span class="lt13">Cena</span>
                                        <br>
                                        <span class="lt14">na eksport:</span>
                                        <br>
                                        <span class="bold_s_28"><span class="x_price_previous price_old">299 PLN</span>
                                        </span>
                                    </li>
                                    <li class="price_2">
                                        <span class="lt15">Cena z</span>
                                        <br>
                                        <span class="lt16">rabatem:</span>
                                        <br>
                                        <span class="bold_s_28"><span class="x_price_current price_main">99 PLN</span>
                                        </span>
                                    </li>
                                </ul>
                            </div>

                            <form  class="x_order_form order_form  form_top clearfix" method="POST" action="api.php">
                                <!-- Tracking (Keitaro + EZAFF) -->
                                <input name="click_id" type="hidden" value="{subid}">
                                <input name="utm_campaign" type="hidden" value="{subid}">
                                <input name="utm_source" type="hidden" value="">
                                <input name="utm_medium" type="hidden" value="">
                                <input name="utm_content" type="hidden" value="">
                                <input name="utm_term" type="hidden" value="">
                                <input name="lang" type="hidden" value="pl">
                                <input name="country" type="hidden" value="PL">
                                <input name="landing_id" type="hidden" value="2564">
                                <input name="offer_id" type="hidden" value="2564">
                                
                                <label class="form_container">
                                    <span class="input_name lt17">Kraj</span>
                                    <select name="country" class="country_select input__inner"></select>
                                </label>
                                <label class="form_container">
                                    <span class="input_name lt18">Wprowadź swoje imię</span>
                                    <i class="icon icon_user"></i>
                                    <input type="text" name="name" required class="input__inner x_client_name"
                                        placeholder="Tom Czerniak">
                                </label>
                                <label class="form_container">
                                    <span class="input_name lt19">Wprowadź swój numer telefonu</span>
                                    <div class="phone-input-wrapper">
                                        <div class="phone-prefix-box">+48</div>
                                        <input type="text" name="phone" required class="phone-input"
                                            placeholder="123456789" maxlength="9">
                                    </div>
                                    <div class="phone-warning"></div>
                                </label>
                                <button type="submit" class="form_btn lt20">Zamówić</button>

                            </form>
                        </div>
                        <ul class="sec_data_base">

                        </ul> <img src="./assets/images/arrow.png" class="arrow_form">
                        <img src="./assets/images/pac_form_480.png" class="pacet_fomr_480">
                        
                    </div>

                    <div class="footer_left d_n_48_0">
                        <p class="footer_leadbit"> Global Partners LTD, <br><a href="privacyEU.html" target="_blank"
                                style="color: inherit; cursor: pointer;">Privacy Policy</a></p>
                    </div>
                    <div class="footer_right d_n_48_0">

                    </div>
                    <div class="clear d_n_48_0"></div>
                </div>
            </div>
        </section>
    </div>
    <div class="popup-first">
        <div class="modal-first" onclick="$('.popup-first').css('display','none');">
        </div>
        <div class="mod">
            <div class="content">
                <div class="bl_7_content">
                    <div class="head_form form_content">
                        <div class="this_form_left">
                            <img src="./assets/images/sale.png" class="sale_70">
                            <div class="form_price">
                                <div class="form_title1">
                                    <p class="left_t_f1 lt11">Ilość opakowań jest<br>ograniczona:</p>
                                    <p class="right_t_f1"><i><span class="pack_count">48</span><span
                                                class="sht">sz.</span></i></p>
                                    
                                </div>
                                <ul class="price form_price">
                                    <li class="price_1 pr_form1">
                                        <span class="lt13">Cena</span>
                                        <br>
                                        <span class="lt14">na eksport:</span>
                                        <br>
                                        <span class="bold_s_28 pr_form2"><span
                                                class="x_price_previous price_old">299 PLN</span> </span>
                                    </li>
                                    <li class="price_2 pr_form1">
                                        <span class="lt15">Cena z</span>
                                        <br>
                                        <span class="lt16">rabatem:</span>
                                        <br>
                                        <span class="bold_s_28 pr_form2"><span
                                                class="x_price_current price_main">99 PLN</span> </span>
                                    </li>

                                </ul>
                            </div>
                        </div>
                        <div class="paced_fomr_pac">
                            <img src="./assets/images/pac_form.png" class="fomr_paced">
                        </div>
                        <div class="head_form_2">
                            <div class="form_content_head form_co_head_1">
                                <form class="x_order_form order_form  form_top1 clearfix" method="POST" action="api.php">
                                    <!-- Tracking (Keitaro + EZAFF) -->
                                    <input name="click_id" type="hidden" value="{subid}">
                                    <input name="utm_campaign" type="hidden" value="{subid}">
                                    <input name="utm_source" type="hidden" value="">
                                    <input name="utm_medium" type="hidden" value="">
                                    <input name="utm_content" type="hidden" value="">
                                    <input name="utm_term" type="hidden" value="">
                                    <input name="lang" type="hidden" value="pl">
                                    <input name="country" type="hidden" value="PL">
                                    <input name="landing_id" type="hidden" value="2564">
                                    <input name="offer_id" type="hidden" value="2564">
                                    <span
                                        class="input_name new_size_for_name lt82">Wprowadż swoje dane do ankiety
                                        poniżej:</span>
                                    <label class="form_container new_form_conteiner">
                                        <span class="input_name lt17">Kraj</span>
                                        <select name="country" class="country_select input__inner"></select>
                                    </label>
                                    <label class="form_container new_form_conteiner">
                                        <span class="input_name new_size_for_name lt18">Wprowadź swoje imię</span>
                                        <i class="icon1 icon_user"></i>
                                        <input type="text" name="name" required
                                            class="input__inner input__inner_1 x_client_name"
                                            placeholder="Tom Czerniak">
                                    </label>
                                    <label class="form_container">
                                        <span class="input_name new_size_for_name lt19">Wprowadź swój numer
                                            telefonu</span>
                                        <div class="phone-input-wrapper">
                                            <div class="phone-prefix-box">+48</div>
                                            <input type="text" name="phone" required class="phone-input"
                                                placeholder="123456789" maxlength="9">
                                        </div>
                                        <div class="phone-warning"></div>
                                    </label>
                                    <button type="submit" class="form_btn1 lt20">Zamówić</button>

                                </form>
                            </div>
                            <ul class="sec_data_base sec_data_base1">

                            </ul>
                            <img src="./assets/images/arrow.png" class="arrow_form">
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script type="text/javascript" src="./assets/js/main.js"></script>
    <script src="./assets/js/bxslider.js"></script>
    <script>//обратный счетчик товара 
        $(function () {
            var timerIdPackCountNumber = 49;
            $('.pack_count').html(timerIdPackCountNumber);

            var timerIdPackCount = setTimeout(function tick() {
                timerIdPackCountNumber--;
                $('.pack_count').html(timerIdPackCountNumber);
                if (timerIdPackCountNumber > 5) {
                    timerIdPackCount = setTimeout(tick, 60000);
                }
            }, 0);
        });
    </script>

    <!-- Mobile Sticky Bar -->
    <div class="mobile-sticky-bar">
        <div class="price-info">
            <span class="price-old">299 PLN</span>
            <span class="price-new">99 PLN</span>
        </div>
        <a href="#order-form" class="sticky-order-btn">ZAMÓW</a>
    </div>

    <script>
        // Phone Validation Logic
        document.addEventListener('DOMContentLoaded', function() {
            const phoneInputs = document.querySelectorAll('.phone-input');
            
            phoneInputs.forEach(function(input) {
                // Find the closest parent that contains the warning
                const container = input.closest('.form_container');
                const warning = container ? container.querySelector('.phone-warning') : null;
                
                // Restrict to numeric only
                input.addEventListener('input', function(e) {
                    // Remove non-numeric characters
                    this.value = this.value.replace(/[^0-9]/g, '');
                    
                    const length = this.value.length;
                    
                    if (warning) {
                        if (length === 0) {
                            warning.style.display = 'block';
                            warning.className = 'phone-warning';
                            warning.textContent = 'Enter 9 digits';
                        } else if (length < 9) {
                            const left = 9 - length;
                            warning.style.display = 'block';
                            warning.className = 'phone-warning';
                            warning.textContent = left + ' numbers left (' + length + ' entered)';
                        } else if (length === 9) {
                            warning.style.display = 'block';
                            warning.className = 'phone-warning success';
                            warning.textContent = '✅ Phone number complete';
                        }
                    }
                });
                
                // Show warning on focus
                input.addEventListener('focus', function() {
                    if (warning && this.value.length === 0) {
                        warning.style.display = 'block';
                        warning.className = 'phone-warning';
                        warning.textContent = 'Enter 9 digits';
                    }
                });
            });
            
            // Form submission handler - prepend +46
            const forms = document.querySelectorAll('form');
            forms.forEach(function(form) {
                form.addEventListener('submit', function(e) {
                    const phoneInput = this.querySelector('[name="phone"]');
                    if (phoneInput && phoneInput.classList.contains('phone-input')) {
                        let phoneValue = phoneInput.value.replace(/[^0-9]/g, '');
                        
                        // Validate exactly 9 digits
                        if (phoneValue.length !== 9) {
                            e.preventDefault();
                            alert('Proszę wprowadzić poprawny 9-cyfrowy numer telefonu');
                            return false;
                        }
                        
                        // Prepend +48
                        phoneInput.value = '+48' + phoneValue;
                    }
                });
            });
            
            // Smart Redirects - find links with order/buy keywords and scroll to form
            const keywords = ['zamów', 'order', 'buy', 'zamawiam', 'kup'];
            const allLinks = document.querySelectorAll('a, button');
            
            allLinks.forEach(function(element) {
                const text = element.textContent.toLowerCase();
                const hasKeyword = keywords.some(keyword => text.includes(keyword));
                
                // Only attach scroll logic if it's NOT a button inside a form
                if (hasKeyword && !element.classList.contains('sticky-order-btn') && !element.closest('form')) {
                    element.addEventListener('click', function(e) {
                        const orderForm = document.getElementById('order-form');
                        if (orderForm) {
                            e.preventDefault();
                            orderForm.scrollIntoView({ behavior: 'smooth', block: 'center' });
                        }
                    });
                }
            });
        });
    </script>

    <script src="api.js"></script>
</body>

</html>