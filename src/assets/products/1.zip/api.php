<?php
session_start();

if ($_SESSION["valid"] == "true") {
	$valid_count = $_SESSION["validcount"];    
	$_SESSION["validcount"] = $valid_count + 1;  
	} else {
	$_SESSION["valid"] = "true";
	$_SESSION["validcount"] = "1";
	$_SESSION["timeout"] = time() + 36000;
}

function get_input($key) {
    return isset($_POST[$key]) ? $_POST[$key] : (isset($_SESSION[$key]) ? $_SESSION[$key] : "");
}

$api_key = "eb9843ac86";
$publisher_id = "3533";
$offer_id = "2350";

$publisher_sub_id    = get_input("pub_sub_id");
$publisher_order_id  = get_input("publisher_order_id");
$click_id            = get_input("click_id");
$extra_id_1          = get_input("extra_id_1");
$extra_id_2          = get_input("extra_id_2");
$stream_id           = get_input("stream_id");


$api_url = "https://api.ezaff.com/send";

function onlyaz($value) {
$result = preg_replace("/[^\s\w+_:,-.]+/u", "", $value);
return $result;
}

function getIPAddress() 
	{
		foreach (array("HTTP_CLIENT_IP", "HTTP_X_FORWARDED_FOR", "HTTP_X_FORWARDED", "HTTP_X_CLUSTER_CLIENT_IP", "HTTP_FORWARDED_FOR", "HTTP_FORWARDED", "REMOTE_ADDR","HTTP_CF_CONNECTING_IP") as $key) {
			if (array_key_exists($key, $_SERVER) === true) {
				foreach (explode(",", $_SERVER[$key]) as $ip) {
					if (filter_var($ip, FILTER_VALIDATE_IP) !== false) {
						return $ip;
					}
				}
			}
		}
	}
	
$post = array(
		"offer_id" => $offer_id,
		"publisher_id" => $publisher_id,
		"api_key" => $api_key,
		"name" => onlyaz($_POST["name"]),
		"phone" =>onlyaz($_POST["phone"]),	
		"email" => "",
		"click_id" => $click_id,
		"publisher_sub_id" => $publisher_sub_id ,
		"publisher_order_id" => $publisher_order_id,
		"extra_id_1" => $extra_id_1,
		"extra_id_2" => $extra_id_2,
		"stream_id" => $stream_id,
		"extra_note" => "",
		"city" => "",
		"post_code" => "",
		"country" => "PL",
		"address" => "",
		"state" => "",
		"district" => "",
		"quantity" => "1",
		"price" => "99",
		"price_currency" => "PLN ",
		"client_ip" => getIPAddress(),
		"order_note" => "",
		"bundle_option" => "",
		"payment_method" => "",
		"browser_agent" => "",
		"ref_url" => $_SERVER["HTTP_HOST"],
		"product_id" => ""
);

if ( !empty($_POST["name"]) && !empty($_POST["phone"]) && ($_SESSION["validcount"] < "100")  ) {
	error_log("API.PHP: Sending to EZAFF - Name: " . $_POST["name"] . ", Phone: " . $_POST["phone"]);
	$ch = curl_init($api_url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
	$response = curl_exec($ch);
	curl_close($ch);
	error_log("API.PHP: EZAFF Response: " . $response);
	$obj = json_decode($response, true);
		if ( $obj["status"] == "success" ) {
			error_log("API.PHP: EZAFF SUCCESS - Redirecting to success.php");
			header("location: success.php");
			exit();
		} else {
			error_log("API.PHP: EZAFF FAILED - Going back. Response: " . print_r($obj, true));
			// Log error to console
			echo "<!DOCTYPE html><html><head><meta charset='UTF-8'><title>Error</title></head><body>";
			echo "<script>";
			echo "console.error('❌ EZAFF API ERROR:', " . json_encode($obj) . ");";
			echo "console.log('📋 Full Response:', " . json_encode($response) . ");";
			echo "console.log('⬅️ Redirecting back to form in 1 second...');";
			echo "setTimeout(function() { window.history.go(-1); }, 1000);";
			echo "</script>";
			echo "<p style='text-align:center; font-family:Arial; padding:50px;'>Processing error. Redirecting back...</p>";
			echo "</body></html>";
			exit();    	
		}	
} else {
	error_log("API.PHP: Validation failed - Name: " . (!empty($_POST["name"]) ? "OK" : "EMPTY") . ", Phone: " . (!empty($_POST["phone"]) ? "OK" : "EMPTY") . ", Count: " . $_SESSION["validcount"]);
	// Log validation error to console
	echo "<!DOCTYPE html><html><head><meta charset='UTF-8'><title>Validation Error</title></head><body>";
	echo "<script>";
	echo "console.error('❌ VALIDATION ERROR');";
	echo "console.log('Name:', " . json_encode(!empty($_POST["name"]) ? "OK" : "EMPTY") . ");";
	echo "console.log('Phone:', " . json_encode(!empty($_POST["phone"]) ? "OK" : "EMPTY") . ");";
	echo "console.log('Session Count:', " . json_encode($_SESSION["validcount"]) . ");";
	echo "console.log('⬅️ Redirecting back to form in 1 second...');";
	echo "setTimeout(function() { window.history.go(-1); }, 1000);";
	echo "</script>";
	echo "<p style='text-align:center; font-family:Arial; padding:50px;'>Validation error. Redirecting back...</p>";
	echo "</body></html>";
	exit();
}	
?>
