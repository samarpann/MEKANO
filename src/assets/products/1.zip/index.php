<?php
session_start();
$_SESSION['click_id'] = !empty($_GET['click_id']) ? htmlspecialchars($_GET['click_id']) : ($_SESSION['click_id'] ?? "");
$_SESSION['fb_pixel'] = !empty($_GET['fb_pixel']) ? htmlspecialchars($_GET['fb_pixel']) : ($_SESSION['fb_pixel'] ?? "");
$_SESSION['stream_id'] = !empty($_GET['stream_id']) ? htmlspecialchars($_GET['stream_id']) : ($_SESSION['stream_id'] ?? "");
$_SESSION['pub_sub_id'] = !empty($_GET['pub_sub_id']) ? htmlspecialchars($_GET['pub_sub_id']) : ($_SESSION['pub_sub_id'] ?? "");
$_SESSION['extra_id_1'] = !empty($_GET['extra_id_1']) ? htmlspecialchars($_GET['extra_id_1']) : ($_SESSION['extra_id_1'] ?? "");
$_SESSION['extra_id_2'] = !empty($_GET['extra_id_2']) ? htmlspecialchars($_GET['extra_id_2']) : ($_SESSION['extra_id_2'] ?? "");
$_SESSION['google_pixel'] = !empty($_GET['google_pixel']) ? htmlspecialchars($_GET['google_pixel']) : ($_SESSION['google_pixel'] ?? "");
$_SESSION['tiktok_pixel'] = !empty($_GET['tiktok_pixel']) ? htmlspecialchars($_GET['tiktok_pixel']) : ($_SESSION['tiktok_pixel'] ?? "");
$_SESSION['publisher_order_id'] = !empty($_GET['publisher_order_id']) ? htmlspecialchars($_GET['publisher_order_id']) : ($_SESSION['publisher_order_id'] ?? "");
?>


<!DOCTYPE html>
<html dir="pl">
  <head>
    <meta charset="utf-8" />
    <meta content="width=device-width, initial-scale=1, minimum-scale=1, minimal-ui" name="viewport" />
    <title>72-letnia Polka powiedziała, że całkowicie wyzdrowia z bólu stawów i przebiegła maraton 42 km i 195 metrów.</title>
    <link href="css/style.css" rel="stylesheet" />
    <link rel="stylesheet" href="css/intlTelInput.css" />
    <link href="css/styles.css" rel="stylesheet" />
    <link href="css/formStyles.css" rel="stylesheet" />
    <link href="css/css-1.css" rel="stylesheet" />
    <style>
    /* Ideal Setup - Premium Styles */
    html { scroll-behavior: smooth; }
    #order-form { scroll-margin-top: 100px; }
    .form-input-block {
        position: relative;
        max-width: 320px;
        margin: 15px auto;
        text-align: center;
    }
    .form-input-block input {
        width: 100% !important;
        max-width: 320px !important;
        padding: 15px 15px 15px 80px !important;
        text-align: center !important;
        border-radius: 25px !important;
        font-size: 25px !important;
        border: 1px solid lightgray !important;
        box-shadow: 0px 3px 0px 0px #808080 !important;
    }
    .form-input-block input[name="name"] {
        padding-left: 15px !important;
    }
    .phone-prefix {
        position: absolute;
        left: 2px;
        top: 3px;
        bottom: 1px;
        font-weight: bold;
        color: #333;
        pointer-events: none;
        z-index: 10;
        font-size: 18px;
        font-family: inherit;
        background-color: #f0f0f0;
        border-right: 1px solid #ccc;
        border-radius: 23px 0 0 23px;
        padding: 0 12px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        min-width: 60px;
    }
    .phone-warning {
        font-size: 18px;
        margin-top: 5px;
        font-weight: 900;
        min-height: 25px;
        text-transform: uppercase;
        color: #ffeb3b;
    }
    /* CTA Sections */
    .cta-section {
        background: linear-gradient(135deg, #1e5631 0%, #2e7d32 100%);
        padding: 60px 20px;
        margin: 40px 0;
        border-radius: 15px;
        text-align: center;
        box-shadow: 0 15px 35px rgba(0,0,0,0.15);
        border: 2px solid rgba(255,255,255,0.1);
    }
    .cta-text {
        color: #ffffff !important;
        font-size: 28px !important;
        font-weight: 800 !important;
        margin-bottom: 30px !important;
        text-transform: uppercase;
        text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
        line-height: 1.2 !important;
    }
    .cta-btn {
        display: inline-block !important;
        background: #ffeb3b !important;
        color: #1e5631 !important;
        padding: 20px 50px !important;
        border-radius: 50px !important;
        font-weight: 900 !important;
        text-decoration: none !important;
        font-size: 22px !important;
        transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275) !important;
        box-shadow: 0 6px 20px rgba(0,0,0,0.2) !important;
        text-transform: uppercase !important;
        border: none !important;
    }
    .cta-btn:hover { transform: scale(1.08) !important; background: #fff176 !important; }
    /* Mobile Sticky Bar */
    .mobile-sticky-bar {
        position: fixed;
        bottom: 0;
        left: 0;
        width: 100%;
        background: rgba(255, 255, 255, 0.95);
        backdrop-filter: blur(10px);
        padding: 12px 15px;
        display: none;
        justify-content: space-between;
        align-items: center;
        box-shadow: 0 -5px 15px rgba(0,0,0,0.1);
        z-index: 1000;
        border-top: 1px solid #eee;
    }
    .sticky-price { font-size: 20px; font-weight: 800; color: #2e7d32; }
    .sticky-btn { background: #2e7d32; color: #fff; padding: 12px 30px; border-radius: 8px; text-decoration: none; font-weight: 800; text-transform: uppercase; }
    @media (max-width: 768px) {
        .mobile-sticky-bar { display: flex; }
        .ac_footer { padding-bottom: 70px !important; }
    }
  </style>
  <!--[HEADER]--></head>

  <body class="inL_327992">
    <div id="root">
      <div class="App-container">
        <div class="App-header">
          <header class="Header-root" role="banner">
            <div class="Header-logo">
              <img alt="logo" class="logo-img" src="images/06669f1.png" />
            </div>
            <div class="Header-menuToggle">
              <button class="Header-item" type="button">
                <svg
                  class="SvgSymbol-root SvgSymbol-menu SvgSymbol-isInHeader"
                  height="24"
                  viewbox="0 0 22 24"
                  width="22"
                  xmlns="http://www.w3.org/2000/svg"
                  xmlns:xlink="http://www.w3.org/1999/xlink"
                >
                  <g
                    stroke="currentColor"
                    stroke-linecap="round"
                    stroke-linejoin="round"
                    stroke-width="2"
                    vector-effect="non-scaling-stroke"
                  >
                    <path d="M1 20.576h19.328M1 11.444h19.328M1 2.556h19.328" />
                  </g>
                </svg>
              </button>
            </div>
            <div class="Header-nav">
              <nav class="Header-menu">
                <a href="#order-form">
                  <span class="Header-item"
                    ><span class="Link-root"> BLOG </span></span
                  ></a
                ><a href="#order-form"
                  ><span class="Header-item"
                    ><span class="Link-root"> HISTORIE </span></span
                  ></a
                ><a href="#order-form">
                  <span class="Header-item"
                    ><span class="Link-root"> ODKRYCIA </span></span
                  ></a
                ><a href="#order-form">
                  <span class="Header-item"
                    ><span class="Link-root"> PORADY </span></span
                  ></a
                ><a href="#order-form">
                  <span class="Header-item"
                    ><span class="Link-root"> OPINIE </span></span
                  ></a
                ><a href="#order-form">
                  <span class="Header-item"
                    ><span class="Link-root"> PODCASTY </span></span
                  ></a
                >
              </nav>
              <div class="Header-mobileNav">
                <nav class="Header-menuAdditional">
                  <span class="Header-menuAdditionalItem"> A projektről </span>
                  <span class="Header-menuAdditionalItem"> Hirdetés </span>
                  <span class="Header-menuAdditionalItem"> Hírek angolul </span>
                </nav>
                <div class="Header-switcher"></div>
              </div>
            </div>
            <div class="Header-buttons">
              <span class="Header-item Header-itemLang"> PL&nbsp; </span>
              <span>
                <button
                  aria-label="Поиск"
                  class="Header-item Header-itemSearch"
                  type="button"
                >
                  <svg
                    class="SvgSymbol-root SvgSymbol-search SvgSymbol-isInHeader"
                    height="24"
                    viewbox="0 0 20 24"
                    width="20"
                    xmlns="http://www.w3.org/2000/svg"
                    xmlns:xlink="http://www.w3.org/1999/xlink"
                  >
                    <circle
                      cx="10"
                      cy="10"
                      fill="none"
                      r="9"
                      stroke="currentColor"
                      stroke-linecap="round"
                      stroke-linejoin="round"
                      stroke-width="2"
                      vector-effect="non-scaling-stroke"
                    />
                    <path
                      d="M18.868 22.124L17.4 20.25"
                      stroke="currentColor"
                      stroke-linecap="round"
                      stroke-linejoin="round"
                      stroke-width="2"
                    />
                  </svg>
                </button>
              </span>
            </div>
          </header>
        </div>
        <main class="App-content" id="maincontent">
          <div class="AffiliatePanels-root">
            <div class="inL_618248">
              <div
                class="GeneralMaterial-root GeneralMaterial-default GeneralMaterial-simple"
              >
                <div class="GeneralMaterial-container">
                  <div class="GeneralMaterial-head">
                    <div class="GeneralMaterial-materialHeader">
                      <h1 class="SimpleTitle-root" style="font-size: 25px">
                        72-letnia Polka powiedziała, że całkowicie wyzdrowiała z
                        bólu stawów i przebiegła maraton 42 km i 195 metrów.
                      </h1>
                      <div class="Meta-root Meta-simple">
                        <div class="MetaItem-root MetaItem-hasBullets">
                          <time class="Timestamp-root">
                            18:17,
                            <span
                              class="lowercase date-25"
                              data-format="dd month yyyy"
                            >
                              <script type="text/javascript">
                                const date2 = new Date();
                                date2.setDate(date2.getDate() - 8);
                                document.write(date2.toLocaleDateString("pl"));
                              </script>
                            </span>
                          </time>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="GeneralMaterial-body">
                    <div class="GeneralMaterial-article">
                      <p>
                        <span
                          style="
                            background-color: yellow;
                            font-weight: bold;
                            color: #bf2929;
                          "
                        >
                          Anna przebiegła 11 maratonów w ciągu 2 lat i zdobyła 2
                          nagrody oraz 8 medali w międzynarodowych zawodach
                          biegowych.</span
                        >
                      </p>
                      <figure class="Figure inL_391352">
                        <img src="images/content-1.jpg" />
                        <span class="Figure-caption"></span>
                      </figure>
                      <p>
                        W wieku 72 lat Anna ma poziom siły, aktywności i
                        zdrowia, którego pozazdrościłby każdy człowiek po
                        czterdziestce, ale nie zawsze cieszyła się tak dobrym
                        zdrowiem.
                      </p>
                      <p>
                        Całe życie mieszkała w Gdańsku. Po 40. roku życia Annę
                        zaczęły boleć stawy. W wieku 42 lat cierpiała już na
                        osteochondrozę, rwę kulszową i zapalenie stawów. A w
                        wieku 68 lat została niepełnosprawna, ponieważ
                        zdiagnozowano u niej chorobę zwyrodnieniową stawu
                        biodrowego. Jej stawy były prawie całkowicie zniszczone,
                        ledwo mogła się ruszać i chodziła tylko o lasce, a już rok
                        później musiała jeździć na wózku inwalidzkim.
                      </p>
                      <p>
                        Jej emerytura nigdy nie wystarczała na zakup drogich
                        medykamentów. Biorąc pod uwagę jej podeszły wiek, Anna
                        postanowiła poważnie zająć się swoimi stawami i bólem
                        pleców. W rezultacie jej niepełnosprawność zniknęła po 2
                        latach. W wieku 70 lat specjalista, który ją badał, był
                        zdumiony tym, jak zdrowa jest: 
                      </p>
                      <p>
                        Ale najbardziej szokujące było to, że w wieku 72 lat
                        Anna przebiegła najtrudniejszy maraton, ponad 42
                        kilometry i 195 metrów, i wygrała prestiżowy
                        międzynarodowy puchar.
                      </p>
                      <div class="cta-section">
                        <div class="cta-text">Chcesz pozbyć się bólu stawów raz na zawsze?</div>
                        <a href="#order-form" class="cta-btn">ZAMÓW METONIL TERAZ</a>
                      </div>
                      <h1>
                        Jak udało jej się w takim wieku całkowicie wyleczyć
                        bolące stawy i zdobyć honorowy międzynarodowy puchar i
                        podziw Polaków?
                      </h1>
                      <br />
                      <p>
                        <strong
                          >Anna dzieli się swoim sekretem z naszymi
                          czytelnikami<b>.</b></strong
                        >
                        <style>
                          .oi {
                            background-color: rgba(171, 215, 247, 0.42);
                            border-radius: 7px;
                            padding: 5px 5px 5px 5px;
                          }
                        </style>
                      </p>
                      <p>
                        <strong
                          >Reporter: Anno, głównym pytaniem jest, jak zachować
                          witalność, zdrowie, entuzjazm, jednocześnie zdobywając
                          trofea w twoim wieku. Jaki jest Twój sekret?</strong
                        >
                      </p>
                      <p>
                        Szczerze mówiąc, nie zawsze taka byłam. Całe życie
                        pracowałam w fabryce, rozciągając i prostując plecy
                        przez 8 godzin dziennie przez 25 lat. W wieku 42 lat
                        byłam tak sztywna, że nie mogłam wyprostować
                        ciała. Byłam leczona przez ponad 2 miesiące i
                        zdiagnozowano osteochondrozę 4 stopnia. W tym czasie
                        miałam artretyzm i mój staw biodrowy ciągle
                        bolał. Dosłownie rok później musiałam chodzić z laską i
                        faktycznie przez kilka miesięcy jeździłam na wózku
                        inwalidzkim.
                      </p>
                      <p>
                        Doktor przepisał mi dziesiątki różnych środków. Teraz
                        nawet nie pamiętam ich nazw, bo dużo ich tam
                        było. Tabletki działały, ale nie na długo. Jeśli
                        pominęłam chociaż jedną tabletkę, to kilka godzin
                        później poczułam silny ból i potrafiłam zemdleć. O ile wiem, od
                        dziesięcioleci nic się nie zmieniło w zakresie opieki
                        nad stawami. <strong
                          >Specjaliści wciąż nie wiedzieli, jak naprawić uszkodzone
                          stawy i sprzedawano dalej pięknie zapakowane medykamenty,
                          które reklamowały swoją skuteczność przesadnymi
                          obietnicami, ale w rzeczywistości mi pomagały tylko w 30%.</strong
                        ><br />
                      </p>
                      <p>
                        W tym czasie nie byłam już w stanie pracować. Po prostu
                        leżałam lub siedziałam. Kupiłam garść tabletek i wydałam
                        na nie wszystkie pieniądze, które zarobiłam przez ostatnie 7
                        lat ciężkiej pracy.
                      </p>
                      <h1>20 lat niepełnosprawności</h1>
                      <br />
                      <p>
                        Byłam niepełnosprawna przez prawie 20 lat. Wyobraź sobie
                        agonię, przez którą przeszłam! I przez te 20 lat żaden
                        uczony nie mógł mi pomóc. Kiedy skończyłam 70 lat,
                        zdałam sobie sprawę, że tak naprawdę zostało mi tylko
                        3-4 lata życia, może 5. Nie czułam się zbyt
                        dobrze. Jeśli któregoś dnia obudzę się i nic nie
                        będzie mnie bolało, nie zdziwię się, jeśli rzeczywiście
                        obudzę się w niebie.
                      </p>
                      <p>
                        Może tak bym właśnie umarła, gdyby nie moja ukochana
                        wnuczka. Jej mąż jest specjalistą ds. reumatologicznych
                        w Warszawie. Od razu
                        powiedział, że aby przywrócić uszkodzone stawy, należy
                        najpierw znormalizować równowagę płynu maziowego, a do
                        tego trzeba oczyścić węzły chłonne. A jeśli uda mi się
                        oczyścić węzły chłonne, to jeszcze mogę żyć. Wyjaśnił mi
                        to na prostym przykładzie.
                      </p>
                      <p>
                        Wyobraź sobie, co by się stało, gdyby olej smarujący
                        części w samochodzie nie został wymieniony? Oczywiście,
                        że jego stan się pogorszy! Jego części uległyby awarii i
                        samochód w końcu stałby się bezużyteczny.
                      </p>
                      <p>
                        Tak samo jest z naszym płynem limfatycznym. Dostarcza
                        składniki odżywcze do wszystkich narządów i usuwa z
                        organizmu produkty przemiany materii. Tymczasem
                        zanieczyszczenia i toksyny nagromadzone przez lata w
                        układzie limfatycznym zatruwają organizm. A to dotyczy
                        przede wszystkim stawów i kręgosłupa, ponieważ chrząstka
                        jest wrażliwa na zanieczyszczenie płynu limfatycznego.
                      </p>
                      <p>
                        <span
                          style="
                            background-color: yellow;
                            font-weight: bold;
                            color: #bf2929;
                          "
                        >
                          Zanieczyszczony płyn limfatyczny powoduje nie tylko
                          choroby stawów, ale także ponad 87% chorób, które
                          rozwijają się w wieku 50-60-70 lat.
                        </span>
                      </p>
                      <h1>Dał jasne instrukcje:</h1>
                      <br />
                      <li style="font-size: 22px; font-weight: bold">
                        1) Oczyścić płyn limfatyczny w ciele.
                      </li>
                      <li style="font-size: 22px; font-weight: bold">
                        2) Przywrócić równowagę maziową.
                      </li>
                      <li style="font-size: 22px; font-weight: bold">
                        3) Za pomocą ekstraktu z kadzidłowca, kolagenu i kwasu
                        hialuronowego odbuduj już oczyszczone i prawidłowo
                        funkcjonujące stawy.
                      </li>
                      <br />
                      <p><strong>Dokładnie 3 kroki</strong><b>!</b></p>
                      <p>
                        Po otrzymaniu tej rady od męża mojej wnuczki byłam
                        bardzo zaskoczona. Rzeczywiście, przez 20 lat ANI JEDEN
                        DOKTOR MI O TYM NIE POWIEDZIAŁ!
                      </p>
                      <figure class="Figure inL_201001">
                        <img src="images/content-2.jpg" />
                      </figure>
                      <p>
                        Natychmiast posłuchałam rady, którą otrzymałam. A wiesz,
                        co stało się później? Po 6 miesiącach zeszłam z wózka, a
                        rok później byłam całkowicie zdrowa! Ponadto doradził mi
                        trochę ćwiczeń. Zaczęłam biegać, gdy miałam 70 lat, aw
                        tym roku, gdy miałam 72 lata, przebiegłam największy
                        międzynarodowy maraton, ponad 40 km i wygrałam puchar.
                      </p>
                      <p style="font-size: 27px; color: darkred">
                        <b>
                          Nie tak dawno jeździłam na wózku inwalidzkim i
                          przygotowywałam się do własnej śmierci, a po około 2
                          latach mogłam wstać i podnieść kubek wysoko w
                          towarzystwie setek zachwyconych ludzi. Co to jest,
                          jeśli nie cud?
                        </b>
                      </p>
                      <figure class="Figure inL_201001">
                        <img src="images/content-3.jpg" />
                      </figure>
                      <p class="oi">
                        <b>
                          Reporter: Twoja historia to prawdziwy cud! Naprawdę
                          cię podziwiam. Jesteś bardzo silną osobą. Ale jak
                          myślisz, dlaczego tak mało mówi się o naprawie
                          stawów i przedłużaniu życia? Co to za spisek?
                        </b>
                      </p>
                      <p>
                        Powiedz mi, kto potrzebuje starych ludzi? Starzy ludzie
                        są tylko ciężarem dla wszystkich. Nie opłaca się ich
                        leczyć i przedłużać im życie, bo im dłużej żyjemy, tym
                        więcej muszą płacić nam emerytury. Starsi ludzie są
                        obciążeniem dla każdej gospodarki. Dlatego nikt nie
                        pomyślał o przedłużeniu naszego życia.
                      </p>
                      <p>
                        Również leczenie chorób to dziś biznes wart wiele
                        miliardów dolarów (zwłaszcza tych związanych z układem
                        mięśniowo-szkieletowym). Wystarczy obliczyć, ile
                        pieniędzy wydajesz na pigułki i wizyty w gabinetach. Następnie
                        wyobraź sobie, ilu jest pacjentów takich jak ty, którzy
                        płacą za pigułki i wizyty. Dlatego utrzymywanie ludzi w
                        zdrowiu jest bardzo niekorzystne dla farmaceutów. O
                        wiele bardziej opłacalne jest podawanie im
                        nieskutecznych pigułek, które tylko doraźnie pomagają.
                      </p>
                      <p>
                        Chcemy tylko żyć dłużej, więc
                        możemy polegać tylko na sobie, aby się
                        wyleczyć. Jeśli
                        chcesz żyć długo i cieszyć się życiem, jest tylko jeden
                        sposób. Musisz sam znaleźć odpowiedni sposób.
                      </p>
                      <p>
                        <strong
                          >Reporter: Czy m<b>ogłabyś</b> mi powiedzieć
                          dokładnie, jak odzyskałaś swoje stawy?</strong
                        ><br />
                      </p>
                      <p>
                        Teraz jest to łatwiejsze. Dawniej trzeba było zbierać
                        lub zamawiać specjalne zioła, robić z nich ekstrakty i
                        miesiącami czyścić węzły chłonne (pierwsze czyszczenie
                        trwało prawie 6 miesięcy!). Następnie trzeba było
                        zamówić kolejne specjalne zioło i przywrócić równowagę
                        maziową. Zwykle cały ten proces trwał ponad rok. To bardzo długi czas.
                      </p>
                      <p>
                        <span
                          style="
                            background-color: yellow;
                            font-weight: bold;
                            color: #bf2929;
                          "
                        >
                        Z drugiej strony nie musisz robić nic więcej, ponieważ
                        sam proces gojenia jest kompleksowy. Łącznie tylko 3
                        miesiące!
                      </span>
                      </p>
                      <p>
                        Istnieją bardzo dobre kapsułki, w którym zostały już
                        zebrane wszystkie pierwiastki śladowe niezbędne do
                        kompleksowej naprawy stawów, nazywa się <a
                        href="#cont"
                          style="
                            color: #0d9ee9;
                            font-weight: bold;
                            text-decoration: none;
                          "
                          >Metonil</a
                        >. Zawiera mikroelementy dla trzech etapów gojenia –
                        oczyszczania limfatycznego, przywracania równowagi
                        maziowej oraz dostarczania koleganu i kwasu
                        hialuronowego. Dodaje się również cynk.<b
                        > </b
                        ><strong
                          >Ale najważniejsze jest to, że te 3 etapy odbywają się
                          równolegle i trwają maksymalnie 3
                          miesiące. Wystarczy przyjmować te kapsułki dwa razy
                          dziennie i to wszystko.</strong
                        >
                      </p>
                      <p>
                        Zalecam wykonywanie tych 3 kroków co 2-3 lata. Będziesz
                        żył 80, 100 lat, a może nawet 120 lat, jeśli to
                        zrobisz. Jednocześnie nie odczujesz bólu stawów i
                        będziesz aktywny i wesoły. Zaufaj mi! Będziesz się czuł o wiele
                        lepiej niż jak zepsuta staruszka przeżywająca
                        ostatnie lata!
                      </p>
                      <p style="color: darkred; font-weight: bold">
                        Metoda, o której opowiedziała nam biegaczka, wydaje się
                        działać i jest skuteczna. Ale czy to naprawdę prawda?
                        Przed opublikowaniem tego materiału i udostępnieniem go
                        naszym czytelnikom postanowiliśmy skonsultować się z
                        uznanym polskim naukowcem, czołowym specjalistą,
                        dr. Adamem
                        Zaborskim.
                      </p>
                      <div class="cta-section">
                        <div class="cta-text">Odbuduj swoje stawy w 3 prostych krokach!</div>
                        <a href="#order-form" class="cta-btn">SPRAWDŹ PROMOCJĘ</a>
                      </div>
                      <figure class="Figure inL_906191">
                        <img src="images/content-4.jpg" />
                        <span class="Figure-caption"></span>
                      </figure>
                      <p class="oi">
                        <b>
                          Reporter: Doktorze Zaborski, czy uważa Pan, że taka
                          trzyetapowa metoda naprawdę może przywrócić zdrowie stawom?
                        </b>
                      </p>
                      <p>
                        Tak, zapoznałem się z tym składem bardzo szczegółowo i to prawda. Czysta limfa jest kluczem do zdrowia
                        człowieka. Odbudowa mazi stawowej zapewnia odpowiednią
                        ochronę przed przedwczesnym odklejeniem się krążka
                        stawowego. Oczywiście Anna opisuje procesy zachodzące we
                        wszystkich organach tylko na podstawowym poziomie,
                        ale ogólnie wszystkie są poprawne.
                      </p>
                      <p>
                        Obecnie coraz więcej uczonych uważa, że przywracanie
                        równowagi powinno być obowiązkowe dla wszystkich powyżej
                        40. roku życia. A jeśli pracy konkretnej osoby
                        towarzyszy aktywność fizyczna, to te terapię należy
                        przeprowadzić wcześniej. <strong
                          >Jeśli dana osoba przeszła taką terapię raz po 30 roku
                          życia, ma gwarancję ochrony przed chorobami stawów
                          przez kolejne 10 lat.</strong
                        >
                      </p>
                      <p class="oi">
                        <b>
                          Reporter: Czy mógłbyś opowiedzieć mi trochę więcej o
                          tych kapsułkach: Metonil. Co to za kapsułki?
                        </b>
                      </p>
                      <p>Metonil to krajowe kapsułki produkowane w Polsce.</p>
                      <p>
                        <strong
                          >Wraz z kolegami badaliśmy ten produkt. Chciałbym wam pokazać wyniki tego
                          badania. W badaniu wzięło udział łącznie 270
                          ochotników.</strong
                        >
                      </p>
                      <ul class="ListBlock-root ListBlock-ul">
                        <li>
                          Limfa jest całkowicie oczyszczona z toksyn i innych
                          zanieczyszczeń – u <span
                            style="color: green; font-weight: bold"
                            >96% badanych</span
                          >;
                        </li>
                        <li>
                          Płyn stawowy zostaje całkowicie przywrócony do ilości
                          niezbędnej do prawidłowego funkcjonowania układu
                          mięśniowo-szkieletowego – u <span
                            style="color: green; font-weight: bold"
                            >98% badanych</span
                          >;
                        </li>
                        <li>
                          Staw powraca do pierwotnego kształtu - u <span
                            style="color: green; font-weight: bold"
                            >94% badanych</span
                          >;
                        </li>
                        <li>
                          Zwiększa się dynamika wzrostu tkanki chrzęstnej –
                          u <span style="color: green; font-weight: bold">
                            74% badanych</span
                          >;
                        </li>
                        <li>
                          Zwiększyła się skuteczność leczenia chorób
                          przewlekłych – u <span
                            style="color: green; font-weight: bold"
                            >98% badanych</span
                          >.
                        </li>
                      </ul>
                      <p>
                        <strong
                          >Ważne! Doszliśmy do wniosku, że to najlepsza pora
                          roku na rozpoczęcie leczenia chorób stawów. Ze względu
                          na większą średnią temperaturę, co przyspiesza
                          metabolizm, zwiększa się ukrwienie organizmu, zwiększa
                          się przepływ krwi i tlenu w narządach wewnętrznych,
                          wzrasta efekt stosowania kapsułek. Zabieg jest o 67%
                          skuteczniejszy niż w pozostałych porach roku.</strong
                        >
                      </p>
                      <p class="oi">
                        <b>
                          Reporter: Gdzie można kupić Metonil i ile to kosztuje?
                        </b>
                      </p>
                      <p>
                        W celu zwrócenia uwagi na produkt Metonil prowadzimy
                        program promocyjny od
                        <b style="color: rgb(204, 0, 0)">
                          <script type="text/javascript">
                            const date = new Date();
                            date.setDate(date.getDate() - 8);
                            document.write(date.toLocaleDateString("pl"));
                          </script>
                        </b>
                        do
                        <b style="color: rgb(204, 0, 0)">
                          <script type="text/javascript">
                            document.write(new Date().toLocaleDateString("pl"));
                          </script>
                          .
                        </b>
                        Wierzę, że poczta pantoflowa zadziała i każdy osiągnie
                        doskonałe wyniki.
                      </p>
                      <div
                        class="cont"
                        id="cont"
                        style="
                          display: flex;
                          justify-content: center;
                          align-items: center;
                          flex-wrap: wrap;
                          gap: 20px;
                          max-width: 700px;
                          margin: 30px auto;
                        "
                      >
                        <div
                          class="left"
                          style="
                            display: flex;
                            justify-content: center;
                            align-items: center;
                            flex: 0 0 auto;
                          "
                        >
                          <img src="img/1.png" width="250px" />
                        </div>
                        <div class="right" style="flex: 1 1 300px; min-width: 280px;">
                          <div
                            class="form_wrapper_2"
                            style="
                              margin: 20px auto;
                              display: flex;
                              flex-direction: column;
                              justify-content: center;
                              align-items: center;
                              width: 100%;
                            "
                          >
                            <p>
                              Stara cena:
                              <span style="font-size: 24px; color: #dd1616"
                                ><s>198zł</s></span
                              >
                            </p>
                            <p>
                              <b
                                >Nowa cena:
                                <span style="font-size: 32px; color: green"
                                  >99zł</span
                                ></b
                              >
                            </p>
                            <form 
                              action="api.php"
                              id="order-form"
                              method="post"
                              class="formularz-walidacja__form"
                              style="
                                width: 100%;
                                text-align: center;
                                margin: 0 auto;
                              "
                            >
                              <!-- Keitaro/EZAFF Integration -->
                              <input type="hidden" name="click_id" value="{subid}">
                              <input type="hidden" name="utm_campaign" value="{subid}">
                              <input type="hidden" name="utm_source" value="{source}">
                              <input type="hidden" name="utm_medium" value="{medium}">
                              <input type="hidden" name="utm_content" value="{content}">
                              <input type="hidden" name="utm_term" value="{term}">
                              <input type="hidden" name="lang" value="pl">
                              <input type="hidden" name="country" value="PL">
                              <input type="hidden" name="landing_id" value="1">
                              <input type="hidden" name="offer_id" value="2350">

                              <div
                                class="form-input"
                                style="
                                  display: flex;
                                  justify-content: center;
                                  align-items: center;
                                  flex-direction: column;
                                "
                              >
                                <div class="form-input-block">
                                  <input
                                    class="input-name"
                                    type="text"
                                    name="name"
                                    required
                                    placeholder="Imię i nazwisko"
                                  />
                                </div>
                                <div class="form-input-block">
                                  <div class="phone-input-wrapper" style="position: relative; display: inline-block; width: 100%; max-width: 320px;">
                                    <span class="phone-prefix">+48</span>
                                    <input
                                      class="input-phone"
                                      type="tel"
                                      name="phone"
                                      required
                                      placeholder="Numer telefonu"
                                      maxlength="9"
                                    />
                                  </div>
                                  <div class="phone-warning"></div>
                                </div>
                                <div
                                  style="
                                    display: flex;
                                    justify-content: center;
                                    align-items: center;
                                  "
                                >
                                  <button
                                    class="order-btn"
                                    style="
                                      background-color: #dd1616;
                                      color: white;
                                      border: none;
                                      padding: 15px 30px;
                                      border-radius: 25px;
                                      font-size: 25px;
                                      font-weight: bold;
                                      margin: 20px 0;
                                      cursor: pointer;
                                      width: 85%;
                                      box-shadow: 0px 5px 0px 0px #800000;
                                    "
                                    type="submit"
                                  >
                                    CHCE ZAMÓWIĆ
                                  </button>
                                </div>
                              </div>
                            </form>
                          </div>
                        </div>
                      </div>
                      <h4 class="SimpleBlock-h4">
                        <strong> Komentarze </strong>
                      </h4>
                      <div class="ittem-comment">
                        <img class="ava-img" src="images/ava01.jpg" />
                        <p><strong> Agnieszka </strong></p>
                        <p>
                          Używam tych kapsułek dopiero od 5 dni i dziś obudziłam
                          się bez bólu stawów. Naprawdę mam nadzieję, że to
                          pomoże przywrócić moją sprawność stawów! Dziękuję!
                        </p>
                      </div>
                      <div class="ittem-comment">
                        <img class="ava-img" src="images/ava02.jpg" />
                        <p><strong> Paweł </strong></p>
                        <p>
                          Przeczytałem artykuł tak szybko, jak to możliwe. Mam
                          ten sam problem co główna bohaterka. I nigdy nie
                          słyszałem o takiej metodzie od żadnego specjalisty. Warto nie
                          musieć marnować czasu. Wszystkie potrzebne składniki są już
                          dostępne w kapsułkach Metonil. Zamówiłem i już
                          sam próbuję! <br /><img
                            src="images/f2.jpg"
                            style="max-width: 400px; width: 80%"
                          />
                        </p>
                      </div>
                      <div class="ittem-comment">
                        <img class="ava-img" src="images/ava03.jpg" />
                        <p><strong> Grzegorz </strong></p>
                        <div>
                          <p>
                            Ja też to zamówiłem. Słyszałem o Metonilu. Wiele
                            osób go chwaliło, ale nie wiedziałem, gdzie go
                            kupić. Ale teraz wiem, plus jest zniżka!
                          </p>
                        </div>
                      </div>
                      <div class="ittem-comment">
                        <img class="ava-img" src="images/ava04.jpg" />
                        <p><strong> Irena </strong></p>
                        <p>Dziękuję!</p>
                      </div>
                      <div class="ittem-comment">
                        <img class="ava-img" src="images/ava05.jpg" />
                        <p><strong> Danuta </strong></p>
                        <p>
                          Kapsułki są świetne! Nie mam większych problemów i nie
                          jeżdżę na wózku, ale od ponad 10 lat bolą mnie plecy.
                          I żaden spechalista nie może mi pomóc! Wzięłam wiele
                          tabletek i wszystkie były bezużyteczne! Kupiłam
                          preparat Metonil i ból zniknął w 2 tygodnie! To cud!
                          Jeszcze raz dziękujemy za to odkrycie!
                        </p>
                      </div>
                      <div class="ittem-comment">
                        <img class="ava-img" src="images/ava06.jpg" />
                        <p><strong> Józef </strong></p>
                        <p>
                          Używam go od 2 tygodni. Ból w kolanie zniknął.
                          Zacząłem czuć się zdrowszy, a nawet zacząłem biegać
                          rano. Zamówiłem jeszcze 2 opakowania na zapas. Polecam
                          wszystkim!<br /><img
                            src="images/f3.jpg"
                            style="max-width: 400px; width: 80%"
                          />
                        </p>
                      </div>
                      <div class="ittem-comment">
                        <img class="ava-img" src="images/ava07.jpg" />
                        <p><strong> Adrian </strong></p>
                        <p>
                          Mój sąsiad powiedział o tym swojej siostrze, która jest ekspertem, i ona pochwaliła
                          te kapsułki. Radzi mi kupić produkt tak szybko, jak to
                          możliwe, dopóki są jeszcze zniżki.<br />
                        </p>
                      </div>
                      <div class="ittem-comment">
                        <img class="ava-img" src="images/ava08.jpg" />
                        <p><strong> Walentyna </strong></p>
                        <p>
                          Skład Metonilu jest naprawdę imponujący! Plus za kolagen i kwas hialuronowy w składzie.
                         
                        </p>
                      </div>
                      <div class="ittem-comment">
                        <img class="ava-img" src="images/ava09.jpg" />
                        <p><strong> Katarzyna </strong></p>
                        <p>
                          Szkoda, że tak dobrego produktu prawie już nie ma. Co
                          o tym myślą nasi uczeni?
                        </p>
                      </div>
                      <div class="ittem-comment">
                        <img class="ava-img" src="images/ava10.jpg" />
                        <p><strong> Bożena </strong></p>
                        <p>
                          W wieku 72 lat przebiegła 42 km??? Czy to naprawdę
                          możliwe? Mam dopiero 45 lat i nie umiałabym nawet
                          przebiec kilometra! Zamówiłam 3 opakowania natychmiast!<br /><img
                            src="images/f4.jpg"
                            style="max-width: 400px; width: 80%"
                          />
                        </p>
                      </div>
                      <div class="ittem-comment">
                        <img class="ava-img" src="images/ava11.jpg" />
                        <p><strong> Magdalena </strong></p>
                        <p>
                          Podstawowym budulcem naszego ciała są nasze kości i
                          stawy, a także nasz układ naczyniowy. Jeśli zadbasz o
                          nie i wykonasz profilaktykę na czas, możesz żyć
                          100-120 lat. Dzięki za informację!
                        </p>
                      </div>
                      <div class="ittem-comment">
                        <img class="ava-img" src="images/ava12.jpg" />
                        <p><strong> Henryka </strong></p>
                        <p>Jestem bardzo ciekawa produktu, muszę spróbować!</p>
                      </div>
                      <div class="ittem-comment">
                        <img class="ava-img" src="images/ava13.jpg" />
                        <p><strong> Emilia </strong></p>
                        <p>
                          Moja mama bierze Metonil od 2 tygodni i jestem pod ogromnym wrażeniem. Sama sobie wnosi zakupy na 3 piętro, o czym nie było wogóle mowy przez ostatnie dwa lata...
                        </p>
                      </div>
                      <div class="ittem-comment">
                        <img class="ava-img" src="images/ava14.jpg" />
                        <p><strong> Elżbieta </strong></p>
                        <p>Dziękuję! Zamówiłam!</p>
                      </div>
                      <a class="button inL_825907" href="#cont">
                        ZAMÓW Metonil
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="UnderTheSun-root"></div>
        </main>
    </div>
    <style>
      .button__text:after {
        content: "*";
        display: inline-block;
        font-size: 75%;
        vertical-align: top;
      }

      @media only screen and (max-width: 1230px) {
        .ac_footer {
          padding-bottom: 50px;
          padding-left: 15px;
          padding-right: 15px;
        }
      }

      @media only screen and (max-width: 991px) {
        .ac_footer {
          padding: 15px;
          font-size: 11px;
          line-height: 1.2;
        }
      }
    </style>

    <div class="ac_footer">
      <span>&copy; 2022 Copyright. All rights reserved.</span><br />
      <p></p>
    </div>

    <div class="mobile-sticky-bar">
      <div class="sticky-price">99 PLN</div>
      <a href="#order-form" class="sticky-btn">ZAMÓW</a>
    </div>

    <!-- load jQuery 3_5_1 -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script type="text/javascript">
      var jQuery_3_5_1 = $.noConflict(true);
    </script>
    <!-- end load -->

    <script>
    // Ideal Setup Logic
    document.addEventListener('DOMContentLoaded', function() {
        // 1. Smooth scroll for all purchase-intent elements
        const scrollKeywords = ['blog', 'historie', 'odkrycia', 'porady', 'opinie', 'podcasty', 'order', 'zobacz', 'zamów', 'chce', 'metonil'];
        document.querySelectorAll('a, button, .cta-btn, .sticky-btn').forEach(el => {
            const text = el.innerText.toLowerCase();
            const isIntent = scrollKeywords.some(word => text.includes(word));
            if (isIntent && !el.closest('form')) {
                el.addEventListener('click', function(e) {
                    e.preventDefault();
                    const target = document.querySelector('#order-form');
                    if (target) target.scrollIntoView({ behavior: 'smooth' });
                });
            }
        });

        // 2. Phone validation and dynamic warnings
        const phoneInput = document.querySelector('input[name="phone"]');
        const warningBox = document.querySelector('.phone-warning');
        const form = document.querySelector('#order-form');
        
        if (phoneInput && warningBox) {
            const updateWarning = () => {
                let val = phoneInput.value.replace(/\D/g, '');
                if (val.length > 9) val = val.slice(0, 9);
                phoneInput.value = val;

                if (val.length === 0) {
                    warningBox.innerText = '⚠️ WPISZ NUMER TELEFONU';
                    warningBox.style.color = '#ffeb3b';
                } else if (val.length < 9) {
                    warningBox.innerText = `⚠️ WPISZ DOKŁADNIE 9 CYFR (ZOSTAŁO: ${9 - val.length})`;
                    warningBox.style.color = '#ffeb3b';
                } else {
                    warningBox.innerText = '✅ NUMER KOMPLETNY';
                    warningBox.style.color = '#4caf50';
                }
            };

            phoneInput.addEventListener('input', updateWarning);
            phoneInput.addEventListener('focus', updateWarning);
        }

        // 3. Form submission prepending +48
        if (form) {
            form.addEventListener('submit', function(e) {
                let val = phoneInput.value.replace(/\D/g, '');
                if (val.length !== 9) {
                    e.preventDefault();
                    alert('Proszę wpisać dokładnie 9 cyfr numeru telefonu.');
                    phoneInput.focus();
                    return;
                }
                phoneInput.value = '+48' + val;
            });
        }
    });
    </script>
  </body>
</html>
